﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Object_Rotation_1 : MonoBehaviour
{
    private float speed2 = 5.0f;
    private float b;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        b = Input.GetAxis("Vertical");
        /*     if(Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow))
         {
         this.transform.Translate(Vector3.forward * speed * Time.deltaTime);
         }

         if (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow))
         {
             this.transform.Translate(Vector3.back * speed * Time.deltaTime);
         }
         */
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            if (b >= 0)
            {
                this.transform.Rotate(0, 0, -speed2 * 6 * Time.deltaTime);
            }
            else
            {
                this.transform.Rotate(0, 0, speed2 * 6 * Time.deltaTime);
            }

        }
        if (Input.GetKey(KeyCode.RightArrow))
        {
            if (b >= 0)
            {
                this.transform.Rotate(0, 0, speed2 * 6 * Time.deltaTime);
            }
            else
            {
                this.transform.Rotate(0, 0, -speed2 * 6 * Time.deltaTime);
            }

        }
    }
}
